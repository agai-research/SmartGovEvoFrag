# HyFragComp — B-READY Business Entry Experimental Dataset

Phase-1 reference dataset: B-READY 2024 Business Entry across all 50 economies.

`raw/` = published source observations/taxonomy.
`derived/` = HyFragComp service, fragment and hypergraph representations.
`synthetic/` = controlled experimental QoS proxies derived from published scores.
`instances/` = controlled requests and repository-scale conditions.

HyFragComp fragments/hypergraph relations are not claimed to be native B-READY records.

Repository scales: 10, 20, 30, 40, 50 economies.
Each condition is configured for 5 runs.
No experimental results are fabricated.
